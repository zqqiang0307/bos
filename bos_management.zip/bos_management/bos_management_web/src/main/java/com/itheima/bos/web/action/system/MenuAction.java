package com.itheima.bos.web.action.system;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;

import com.itheima.bos.domain.base.Standard;
import com.itheima.bos.domain.system.Menu;
import com.itheima.bos.domain.system.User;
import com.itheima.bos.service.system.MenuService;
import com.itheima.bos.web.action.common.CommonAction;

import net.sf.json.JSONObject;

/**
 * 菜单管理
 */
@Namespace("/")
@ParentPackage("struts-default")
@Controller
@Scope("prototype")
public class MenuAction extends CommonAction<Menu>{
	@Autowired
	private MenuService service;
	/**
	 * 查询所有菜单数据，返回json
	 */
	@Action(value="menuAction_listajax")
	public String listajax(){
		List<Menu> list = service.findAll();
		this.java2Json(list, new String[]{"roles","childrenMenus","parentMenu"});
		return NONE;
	}
	
	/**
	 * 保存菜单数据
	 */
	@Action(value="menuAction_save",
			results={@Result(name="success",type="redirect",location="/pages/system/menu.html")})
	public String save(){
		service.save(getModel());
		return SUCCESS;
	}
	
	/**
	 * 菜单数据分页查询
	 */
	@Action(value="menuAction_pageQuery")
	public String pageQuery() throws Exception{
		String string = getModel().getPage();
		page = Integer.parseInt(string);
		//创建一个pageable对象，封装分页参数，用于分页查询
		Pageable pageable = new PageRequest(page - 1, rows);
		Page<Menu> page = service.pageQuery(pageable);
		this.page2Json(page, new String[]{"roles","childrenMenus","parentMenu"});
		return NONE;
	}
	
	/**
	 * 根据登录人查询对应的菜单
	 */
	@Action(value="menuAction_findMenu")
	public String findMenu() throws Exception{
		Subject subject = SecurityUtils.getSubject();
		User user = (User) subject.getPrincipal();
		List<Menu> list = service.findByUser(user);
		this.java2Json(list, new String[]{"roles","childrenMenus","parentMenu","children"});
		return NONE;
	}
}
