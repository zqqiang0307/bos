package com.itheima.bos.web.action.common;

import java.io.IOException;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;
import org.springframework.data.domain.Page;

import com.itheima.bos.domain.base.Courier;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

/**
 * 通用Action抽取
 */
public class CommonAction<T> extends ActionSupport implements ModelDriven<T> {
	private T model;// 声明模型对象

	public T getModel() {
		return model;
	}

	// 在运行期动态获得泛型的具体类型，并通过反射创建model对象
	public CommonAction() {
		// 获得父类（CommonAction）对应的类型
		ParameterizedType genericSuperclass = (ParameterizedType) this.getClass().getGenericSuperclass();
		// 获得父类上声明的泛型类型数组
		Type[] actualTypeArguments = genericSuperclass.getActualTypeArguments();
		// 获得实体类型
		Class<T> entityClass = (Class<T>) actualTypeArguments[0];
		// 通过反射创建model对象
		try {
			model = entityClass.newInstance();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
	}

	// 使用属性驱动接收页面提交的分页参数
	protected int page;// 当前页码
	protected int rows;// 每页显示的记录数

	public void setPage(int page) {
		this.page = page;
	}

	public void setRows(int rows) {
		this.rows = rows;
	}
	
	//将分页数据转为json响应到页面
	public void page2Json(Page page,String[] excludes){
		long total = page.getTotalElements();
		List<T> rows = page.getContent();
		Map<String, Object> map = new HashMap<>();
		map.put("total", total);
		map.put("rows", rows);
		//JSONObject是将单个的Java对象或者Map对象转为json
		//JSONArray是将数组、集合对象转为json
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setExcludes(excludes);
		String json = JSONObject.fromObject(map,jsonConfig).toString();
		//使用输出流将json数据写回客户端浏览器
		ServletActionContext.getResponse().setContentType("text/json;charset=UTF-8");
		try {
			ServletActionContext.getResponse().getWriter().print(json);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	//将分页数据转为json响应到页面
	public void java2Json(List list,String[] excludes){
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setExcludes(excludes);
		String json = JSONArray.fromObject(list,jsonConfig).toString();
		//使用输出流将json数据写回客户端浏览器
		ServletActionContext.getResponse().setContentType("text/json;charset=UTF-8");
		try {
			ServletActionContext.getResponse().getWriter().print(json);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
