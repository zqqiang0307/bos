package com.itheima.bos.web.action.base;

import java.util.List;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;

import com.itheima.bos.domain.base.Courier;
import com.itheima.bos.domain.base.FixedArea;
import com.itheima.bos.service.base.FixedAreaService;
import com.itheima.bos.web.action.common.CommonAction;
import com.itheima.crm.service.Customer;
import com.itheima.crm.service.CustomerService;
@Namespace("/")
@ParentPackage("struts-default")
@Controller
@Scope("prototype")
public class FixedAreaAction extends CommonAction<FixedArea>{
	@Autowired
	private FixedAreaService service;
	@Action(value="fixedAreaAction_save",results={@Result(name="success",location="/pages/base/fixed_area.html",type="redirect")})
	public String save(){
		service.save(getModel());
		return SUCCESS;
	}
	
	@Action(value="fixedAreaAction_pageQuery")
	public String pageQuery() throws Exception{
		Pageable pageable = new PageRequest(page - 1, rows);
		Page<FixedArea> page = service.pageQuery(pageable);
		page2Json(page, new String[]{"subareas","couriers"});
		return NONE;
	}
	
	//注入CRM服务客户端代理对象
	@Autowired
	private CustomerService crmProxy;
	
	/**
	 * 查询未关联到定区的客户数据
	 */
	@Action(value="fixedAreaAction_findCustomersNotAssociation")
	public String findCustomersNotAssociation(){
		List<Customer> list = crmProxy.findCustomersNotAssociation();
		java2Json(list, new String[]{});
		return NONE;
	}
	
	/**
	 * 查询已关联到指定定区的客户数据
	 */
	@Action(value="fixedAreaAction_findCustomersHasAssociation")
	public String findCustomersHasAssociation(){
		List<Customer> list = crmProxy.findCustomersHasAssociation(getModel().getId());
		java2Json(list, new String[]{});
		return NONE;
	}
	
	//属性驱动，接收客户id
	private List<Integer> customerIds;
	
	public void setCustomerIds(List<Integer> customerIds) {
		this.customerIds = customerIds;
	}

	/**
	 * 将客户关联到定区
	 */
	@Action(value="fixedAreaAction_assignCustomers2FixedArea",results={@Result(name="success",location="/pages/base/fixed_area.html",type="redirect")})
	public String assignCustomers2FixedArea(){
		String id = getModel().getId();
		crmProxy.assignCustomers2FixedArea(id, customerIds);
		return SUCCESS;
	}
	
	//属性驱动，接收快递员id、收派时间id
	private Integer courierId;
	private Integer takeTimeId;
	
	public void setCourierId(Integer courierId) {
		this.courierId = courierId;
	}

	public void setTakeTimeId(Integer takeTimeId) {
		this.takeTimeId = takeTimeId;
	}

	/**
	 * 定区关联快递员
	 */
	@Action(value="fixedAreaAction_associationCourierToFixedArea",results={@Result(name="success",location="/pages/base/fixed_area.html",type="redirect")})
	public String associationCourierToFixedArea(){
		service.associationCourierToFixedArea(getModel().getId(),courierId,takeTimeId);
		return SUCCESS;
	}
}
