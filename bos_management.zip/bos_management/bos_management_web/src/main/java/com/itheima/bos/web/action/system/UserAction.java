package com.itheima.bos.web.action.system;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import com.itheima.bos.domain.system.User;
import com.itheima.bos.service.system.UserService;
import com.itheima.bos.web.action.common.CommonAction;

/**
 * 用户管理
 */
@Namespace("/")
@ParentPackage("struts-default")
@Controller
@Scope("prototype")
public class UserAction extends CommonAction<User>{
	//属性驱动，接收页面输入的验证码
	private String checkcode;
	
	public void setCheckcode(String checkcode) {
		this.checkcode = checkcode;
	}
	
	/**
	 * 基于shiro框架实现后台系统用户认证
	 */
	@Action(value="userAction_login",results={@Result(name="home",type="redirect",location="/index.html"),
									@Result(name="login",type="redirect",location="/login.html")})
	public String login(){
		//从session中获取生成的验证码
		String validatecode = (String) ServletActionContext.getRequest().getSession().getAttribute("key");
		if(StringUtils.isNotBlank(checkcode) && StringUtils.isNotBlank(validatecode) && checkcode.equals(validatecode)){
			//输入的验证码正确
			Subject subject = SecurityUtils.getSubject();//获得当前用户对象
			//用户名密码令牌
			AuthenticationToken token = new UsernamePasswordToken(getModel().getUsername(), getModel().getPassword());
			try{
				subject.login(token);
				User user = (User) subject.getPrincipal();
				ServletActionContext.getRequest().getSession().setAttribute("loginUser", user);
				return "home";
			}catch(Exception e){
				e.printStackTrace();
			}
		}else{
			//输入的验证码不正确，跳回登录页面
			return LOGIN;
		}
		return LOGIN;
	}

	/**
	 * 用户注销
	 */
	@Action(value="userAction_logout",results={@Result(name="home",type="redirect",location="/index.html"),
			@Result(name="login",type="redirect",location="/login.html")})
	public String logout(){
		SecurityUtils.getSubject().logout();
		return LOGIN;
	}
	
	//使用属性驱动方式接收多个角色id
	private Integer[] roleIds;
	
	public void setRoleIds(Integer[] roleIds) {
		this.roleIds = roleIds;
	}

	@Autowired
	private UserService service;
	
	/**
	 * 保存用户
	 */
	@Action(value="userAction_save",results={@Result(name="home",type="redirect",location="/index.html"),
			@Result(name="success",type="redirect",location="/pages/system/userlist.html")})
	public String save(){
		service.save(getModel(),roleIds);
		return SUCCESS;
	}
	
	/**
	 * 查询所有用户数据，返回json
	 */
	@Action(value="userAction_findAll")
	public String findAll(){
		List<User> list = service.findAll();
		this.java2Json(list,new String[]{"roles"});
		return NONE;
	}
}
