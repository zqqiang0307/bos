package com.itheima.bos.web.action.system;

import java.util.List;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;

import com.itheima.bos.domain.system.Permission;
import com.itheima.bos.domain.system.Role;
import com.itheima.bos.service.system.RoleService;
import com.itheima.bos.web.action.common.CommonAction;

/**
 * 角色数据管理
 */
@Namespace("/")
@ParentPackage("struts-default")
@Controller
@Scope("prototype")
public class RoleAction extends CommonAction<Role> {
	@Autowired
	private RoleService service;
	/**
	 * 查询所有角色数据
	 */
	@Action(value="roleAction_findAll")
	public String findAll() throws Exception{
		List<Role> list = service.findAll();
		this.java2Json(list, new String[]{"permissions","users","menus"});
		return NONE;
	}
	
	//属性驱动，接收拼接的菜单id，形式为：1,2,3,4,5
	private String menuIds;
	
	//属性驱动，接收多个权限id
	private Integer[] permissionIds;
	
	public void setPermissionIds(Integer[] permissionIds) {
		this.permissionIds = permissionIds;
	}

	public void setMenuIds(String menuIds) {
		this.menuIds = menuIds;
	}

	/**
	 * 添加角色
	 */
	@Action(value="roleAction_save",
			results={@Result(name="success",type="redirect",location="/pages/system/role.html")})
	public String save() throws Exception{
		service.save(getModel(),menuIds,permissionIds);
		return SUCCESS;
	}
}
