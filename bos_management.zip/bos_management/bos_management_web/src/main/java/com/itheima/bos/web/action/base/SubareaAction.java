package com.itheima.bos.web.action.base;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import com.itheima.bos.domain.base.SubArea;
import com.itheima.bos.service.base.SubareaService;
import com.itheima.bos.utils.FileUtils;
import com.itheima.bos.web.action.common.CommonAction;

/**
 * 分区管理
 */
@Namespace("/")
@ParentPackage("struts-default")
@Controller
@Scope("prototype")
public class SubareaAction extends CommonAction<SubArea>{
	@Autowired
	private SubareaService service;
	
	/**
	 * 保存分区
	 */
	@Action(value="subareaAction_save",results={@Result(name="success",location="/pages/base/sub_area.html",type="redirect")})
	public String save(){
		service.save(getModel());
		return SUCCESS;
	}
	
	/**
	 * 分区数据导出
	 * @return
	 * @throws IOException 
	 */
	@Action(value="subareaAction_exportXls")
	public String exportXls() throws IOException{
		//1、查询所有分区数据
		List<SubArea> list = service.findAll();
		//2、基于POI在内存中创建一个Excel文件
		HSSFWorkbook excel = new HSSFWorkbook();
		//3、在Excel文件中创建一个sheet页
		HSSFSheet sheet = excel.createSheet("分区数据统计");
		//4、在标签页中创建行
		HSSFRow title = sheet.createRow(0);
		//5、在行中创建列
		title.createCell(0).setCellValue("编号");
		title.createCell(1).setCellValue("分区起始编号");
		title.createCell(2).setCellValue("分区结束编号");
		title.createCell(3).setCellValue("分区关键字");
		title.createCell(4).setCellValue("辅助关键字");
		title.createCell(5).setCellValue("区域信息");
		for(SubArea subarea : list){
			//每个分区对象对应一行数据
			HSSFRow data = sheet.createRow(sheet.getLastRowNum() + 1);
			//在行中创建列
			data.createCell(0).setCellValue(subarea.getId());
			data.createCell(1).setCellValue(subarea.getStartNum());
			data.createCell(2).setCellValue(subarea.getEndNum());
			data.createCell(3).setCellValue(subarea.getKeyWords());
			data.createCell(4).setCellValue(subarea.getAssistKeyWords());
			data.createCell(5).setCellValue(subarea.getArea().getName());
		}
		
		//6、通过输出流写回Excel文件到浏览器,文件下载需要一个流（输出流）、两个头（设置头信息）
		ServletOutputStream out = ServletActionContext.getResponse().getOutputStream();
		String filename = "分区数据统计结果.xls";
		String agent = ServletActionContext.getRequest().getHeader("User-Agent");//客户端使用的浏览器类型
		//处理中文文件名
		filename = FileUtils.encodeDownloadFilename(filename, agent);
		String mimeType = ServletActionContext.getServletContext().getMimeType(filename);
		ServletActionContext.getResponse().setContentType(mimeType);
		ServletActionContext.getResponse().setHeader("content-disposition", "attachment;filename=" + filename);
		excel.write(out);
		return NONE;
	}
	
	/**
	 * 查询数据，用于展示分区分布图
	 */
	@Action(value="subareaAction_showSubareaChart")
	public String showSubareaChart(){
		List<Object[]> list = service.findSubareas();
		this.java2Json(list, null);
		return NONE;
	}
	

    @Action("subareaAction_findAll")
    public void findAll() {

        Pageable pageable = new PageRequest(page -1,rows);

        Page<SubArea> page = subAreaService.findAllByPage(pageable);

        this.page2Json(page,new String[]{"area"});

    }
}
