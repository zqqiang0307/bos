package com.itheima.bos.web.action.base;

import java.util.List;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.itheima.bos.domain.base.Courier;
import com.itheima.bos.domain.base.TakeTime;
import com.itheima.bos.service.base.TakeTimeService;
import com.itheima.bos.web.action.common.CommonAction;

/**
 * 收派时间管理
 */
@Namespace("/")
@ParentPackage("struts-default")
@Controller
@Scope("prototype")
public class TakeTimeAction extends CommonAction<TakeTime> {
	@Autowired
	private TakeTimeService service;

	/**
	 * 查询所有的收派时间列表，返回json数据
	 */
	@Action(value="taketimeAction_listajax")
	public String listajax(){
		List<TakeTime> list = service.findAll();
		this.java2Json(list, null);
		return NONE;
	}
}
