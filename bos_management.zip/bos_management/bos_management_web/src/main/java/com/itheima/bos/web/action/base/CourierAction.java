package com.itheima.bos.web.action.base;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Controller;

import com.itheima.bos.domain.base.Courier;
import com.itheima.bos.domain.base.Standard;
import com.itheima.bos.service.base.CourierService;
import com.itheima.bos.web.action.common.CommonAction;
import com.itheima.crm.service.Customer;
import com.itheima.crm.service.CustomerService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

/**
 * 快递员管理
 */
@Namespace("/")
@ParentPackage("struts-default")
@Controller
@Scope("prototype")
public class CourierAction extends CommonAction<Courier>{
	
	
	@Autowired
	private CourierService service;
	
	/**
	 * 保存快递员
	 */
	@Action(value="courierAction_save",results={@Result(name="success",location="/pages/base/courier.html",type="redirect")})
	public String save(){
		service.save(this.getModel());
		return SUCCESS;
	}
	
	@Autowired
	private CustomerService crmProxy;
	
	/**
	 * 快递员分页查询（没有过滤条件）
	 * @throws Exception 
	 */
	@Action(value="courierAction_pageQuery")
	public String pageQuery() throws Exception{
		List<Customer> list = crmProxy.findAll();
		System.out.println(list);
		final String company = getModel().getCompany();
		final String courierNum = getModel().getCourierNum();
		final String type = getModel().getType();
		final Standard standard = getModel().getStandard();
		
		Specification<Courier> spe = new Specification<Courier>(){
			//动态根据页面提交的参数封装查询条件
			public Predicate toPredicate(Root<Courier> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				//用于收集查询条件对象
				List<Predicate> list = new ArrayList<>();
				if(StringUtils.isNotBlank(company)){
					//需要条件一个过滤条件，根据公司模糊查询
					Predicate p1 = cb.like(root.get("company").as(String.class), "%"+company+"%");//where company like ? 
					list.add(p1);
				}
				if(StringUtils.isNotBlank(courierNum)){
					//需要条件一个过滤条件，根据工号等值查询
					Predicate p2 = cb.equal(root.get("courierNum").as(String.class), courierNum);//where company like ? 
					list.add(p2);
				}
				if(StringUtils.isNotBlank(type)){
					//需要条件一个过滤条件，根据快递员类型等值查询
					Predicate p3 = cb.equal(root.get("type").as(String.class), type);//where company like ? 
					list.add(p3);
				}
				if(standard != null && StringUtils.isNotBlank(standard.getName())){
					//需要条件一个过滤条件，根据收派标准名称等值查询
					Join<Object, Object> join = root.join("standard");
					Predicate p4 = cb.equal(join.get("name").as(String.class), standard.getName());//where company like ? 
					list.add(p4);
				}
				
				if(list.size() == 0){
					//没有过滤条件
					return null;
				}
				
				Predicate[] ps = new Predicate[list.size()];
				return cb.and(list.toArray(ps));
			}
		};
		
		//创建一个pageable对象，封装分页参数，用于分页查询
		Pageable pageable = new PageRequest(page - 1, rows);
		Page<Courier> page = service.pageQuery(spe, pageable);
		page2Json(page, new String[]{"fixedAreas","takeTime"});
		return NONE;
	}
	
	//属性驱动，接收多个id拼接的字符串1,2,3,4
	private String ids;
	
	public void setIds(String ids) {
		this.ids = ids;
	}
	
	/**
	 * 快递员批量删除（逻辑删除）
	 */
	@Action(value="courierAction_deleteBatch",results={@Result(name="success",location="/pages/base/courier.html",type="redirect")})
	public String deleteBatch(){
		service.deleteBatch(ids);
		return SUCCESS;
	}
	
	/**
	 * 查询所有未删除的快递员
	 */
	@Action(value="courierAction_listajax")
	public String listajax(){
		List<Courier> list = service.findCouriersNotDelete();
		this.java2Json(list, new String[]{"fixedAreas","takeTime","standard"});
		return NONE;
	}
}
