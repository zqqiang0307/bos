package com.itheima.bos.web.action.base;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;

import com.itheima.bos.domain.base.Standard;
import com.itheima.bos.service.base.StandardService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * 收派标准管理
 */
@Namespace("/")
@ParentPackage("struts-default")
@Controller
@Scope("prototype")
public class StandardAction extends ActionSupport implements ModelDriven<Standard>
{
	private Standard model = new Standard();
	public Standard getModel() {
		return model;
	}

	@Autowired
	private StandardService service;
	
	/**
	 * 保存收派标准
	 */
	@Action(value="standardAction_save",results={@Result(name="success",location="/pages/base/standard.html",type="redirect")})
	public String save(){
		//获取当前用户对象
		Subject subject = SecurityUtils.getSubject();
		//检查当前用户是否具有指定的权限,如果没有权限框架会抛出异常
		subject.checkPermission("standard:add");
		service.save(model);
		return SUCCESS;	
	}
	
	//使用属性驱动接收页面提交的分页参数
	private int page;//当前页码
	private int rows;//每页显示的记录数
	
	public void setPage(int page) {
		this.page = page;
	}
	public void setRows(int rows) {
		this.rows = rows;
	}
	
	/**
	 * 收派标准分页查询
	 * @throws Exception 
	 */
	@Action(value="standardAction_pageQuery")
	public String pageQuery() throws Exception{
		//创建一个pageable对象，封装分页参数，用于分页查询
		Pageable pageable = new PageRequest(page - 1, rows);
		Page<Standard> page = service.pageQuery(pageable);
		long total = page.getTotalElements();
		List<Standard> rows = page.getContent();
		Map<String, Object> map = new HashMap<>();
		map.put("total", total);
		map.put("rows", rows);
		//JSONObject是将单个的Java对象或者Map对象转为json
		//JSONArray是将数组、集合对象转为json
		String json = JSONObject.fromObject(map).toString();
		//使用输出流将json数据写回客户端浏览器
		ServletActionContext.getResponse().setContentType("text/json;charset=UTF-8");
		ServletActionContext.getResponse().getWriter().print(json);
		return NONE;
	}
	
	/**
	 * 查询所有收派标准数据，返回json
	 * @throws Exception 
	 */
	@Action(value="standardAction_findAll")
	public String findAll() throws Exception{
		List<Standard> list = service.findAll();
		String json = JSONArray.fromObject(list).toString();
		//使用输出流将json数据写回客户端浏览器
		ServletActionContext.getResponse().setContentType("text/json;charset=UTF-8");
		ServletActionContext.getResponse().getWriter().print(json);
		return NONE;
	}

}
