package bos_management_web;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.junit.Test;

public class POITest {
	/**
	 * 使用POI解析Excel文件
	 * @throws Exception 
	 * @throws FileNotFoundException 
	 */
	@Test
	public void test1() throws FileNotFoundException, Exception{
		String filePath = "C:\\Users\\zhaoqx\\Desktop\\速运快递项目(黑马54期)\\速运快递项目-day04\\资料\\03_区域测试数据\\区域导入测试数据.xls";
		//通过输入流加载指定的Excel文件
		HSSFWorkbook workbook = new HSSFWorkbook(new FileInputStream(new File(filePath)));
		//指定读取哪个标签页Sheet
		HSSFSheet sheet = workbook.getSheetAt(0);
		//遍历标签页中所有的行
		for (Row row : sheet) {
			int rowNum = row.getRowNum();
			if(rowNum == 0){
				//当前解析到的是第一行
				continue;
			}
			for (Cell cell : row) {
				//遍历行中所有的单元格
				String value = cell.getStringCellValue();
				System.out.print(value + " ");
			}
			System.out.println();
		}
	}
}
