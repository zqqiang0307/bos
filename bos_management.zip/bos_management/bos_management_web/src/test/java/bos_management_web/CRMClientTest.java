package bos_management_web;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.itheima.crm.service.CustomerService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="classpath:applicationContext.xml")
public class CRMClientTest {
	@Autowired
	private CustomerService proxy;
	
	@Test
	public void test1(){
		String id = proxy.findFixedAreaIdByAddress("北京市海淀区建材城西路金燕龙办公楼一层");
		System.out.println(id);
	}
}
