package bos_management_web;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.itheima.bos.dao.base.StandardDao;
import com.itheima.bos.domain.base.Standard;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="classpath:applicationContext.xml")
public class SpringDataJpaTest {
	@Autowired
	private StandardDao dao;
	
	//测试使用spring data JPA 查询方法 
	@Test
	public void test1(){
		List<Standard> list = dao.findAll();
		for (Standard standard : list) {
			System.out.println(standard);
		}
	}
	
	//测试使用spring data JPA 保存方法 
	@Test
	public void test2(){
		Standard standard = new Standard();
		standard.setName("标准一");
		dao.save(standard);
	}
	
	//测试使用spring data JPA 删除方法 
	@Test
	public void test3(){
		dao.delete(1);
	}
	
	//测试使用spring data JPA 修改方法 
	@Test
	public void test4(){
		Standard standard = new Standard();
		standard.setId(2);
		standard.setName("标准2");
		dao.save(standard);
	}
	
	//测试使用spring data JPA 根据id查询方法 
	@Test
	public void test5(){
		Standard standard = dao.findOne(2);
		System.out.println(standard);
	}
	
	//测试使用spring data JPA 根据name查询方法 
	@Test
	public void test6(){
		Standard standard = dao.findByNameLike("标准2");
		System.out.println(standard);
		/*List<Standard> list = dao.findByName("标准2");
		for (Standard standard2 : list) {
			System.out.println(standard2);
		}*/
		List<Standard> list = dao.findByNameIsNull();
		Standard findByNamexxxLike = dao.findByNamexxLike("标准2");
		List<Standard> list2 = dao.findByNameAndOperatorxxx("1", "标准2");
		System.out.println(list2);
	}
	
	//测试使用spring data JPA 根据name删除方法 
	@Test
	@Transactional
	public void test7(){
		dao.deleteByName("标准2");
	}
}
