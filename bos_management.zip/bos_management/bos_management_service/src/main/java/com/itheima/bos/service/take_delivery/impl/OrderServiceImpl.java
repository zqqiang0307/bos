package com.itheima.bos.service.take_delivery.impl;

import java.util.Date;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import com.itheima.bos.dao.base.AreaDao;
import com.itheima.bos.dao.base.FixedAreaDao;
import com.itheima.bos.dao.take_delivery.OrderDao;
import com.itheima.bos.dao.take_delivery.WorkbillDao;
import com.itheima.bos.domain.base.Area;
import com.itheima.bos.domain.base.Courier;
import com.itheima.bos.domain.base.FixedArea;
import com.itheima.bos.domain.base.SubArea;
import com.itheima.bos.domain.take_delivery.Order;
import com.itheima.bos.domain.take_delivery.WorkBill;
import com.itheima.bos.service.take_delivery.OrderService;
import com.itheima.crm.service.CustomerService;

//@Service
@Transactional
public class OrderServiceImpl implements OrderService{
	@Autowired
	private OrderDao dao;
	@Autowired
	private AreaDao areaDao;
	@Autowired
	private CustomerService crmProxy;
	@Autowired
	private FixedAreaDao fixedAreaDao;
	@Autowired
	private WorkbillDao workbillDao;
	/**
	 * 保存订单，需要完成自动分单
	 */
	public void save(Order order) {
		//根据订单中区域信息（省市区）查询数据库，获取持久状态的区域对象
		Area sendArea = order.getSendArea();
		Area recArea = order.getRecArea();
		if(sendArea != null){
			Area dbSendArea= areaDao.findByProvinceAndCityAndDistrict(sendArea.getProvince(), sendArea.getCity(), sendArea.getDistrict());		
			order.setSendArea(dbSendArea);
		}
		
		if(recArea != null){
			Area dbRecArea= areaDao.findByProvinceAndCityAndDistrict(recArea.getProvince(), recArea.getCity(), recArea.getDistrict());		
			order.setRecArea(dbRecArea);
		}
		
		//1、保存订单信息到订单表
		order.setOrderTime(new Date());//下单时间
		order.setOrderNum(UUID.randomUUID().toString());//订单编号
		dao.save(order);
		
		//2、基于CRM地址库完全匹配法实现自动分单
		if(StringUtils.isNotBlank(order.getSendAddress())){
			String fixedAreaId = crmProxy.findFixedAreaIdByAddress(order.getSendAddress());
			if(fixedAreaId != null){
				FixedArea fixedArea = fixedAreaDao.findOne(fixedAreaId);
				Set<Courier> couriers = fixedArea.getCouriers();
				//根据上下班时间进行匹配，匹配到正在值班的快递员
				Iterator<Courier> iterator = couriers.iterator();
				if(iterator.hasNext()){
					//查询到定区id了，可以完成自动分单
					order.setOrderType("自动分单");
					Courier courier = iterator.next();
					order.setCourier(courier);
					//为快递员产生一个工单
					WorkBill workBill = new WorkBill();
					workBill.setAttachbilltimes(0);
					workBill.setBuildtime(new Date());
					workBill.setCourier(courier);
					workBill.setOrder(order);
					workBill.setPickstate("新单");
					workBill.setRemark(order.getRemark());
					workBill.setSmsNumber("123");
					workBill.setType("新");
					workbillDao.save(workBill);//保存工单
					//调用短信平台为快递员发送短信
					System.out.println("工单信息：请到"+order.getSendAddress()+"取件，客户电话："+order.getSendMobile());
					return ;
				}
			}
		}
		
		//3、基于分区关键字匹配法实现自动分单
		if(order.getSendArea() != null){
			//获得指定区域中包含的所有分区
			Set<SubArea> subareas = order.getSendArea().getSubareas();
			for (SubArea subArea : subareas) {
				String keyWords = subArea.getKeyWords();//分区关键字
				String assistKeyWords = subArea.getAssistKeyWords();//辅助关键字
				if(order.getSendAddress().contains(keyWords) || order.getSendAddress().contains(assistKeyWords)){
					FixedArea fixedArea = subArea.getFixedArea();
					Set<Courier> couriers = fixedArea.getCouriers();
					//根据上下班时间进行匹配，匹配到正在值班的快递员
					Iterator<Courier> iterator = couriers.iterator();
					if(iterator.hasNext()){
						//查询到定区id了，可以完成自动分单
						order.setOrderType("自动分单");
						Courier courier = iterator.next();
						order.setCourier(courier);
						//为快递员产生一个工单
						WorkBill workBill = new WorkBill();
						workBill.setAttachbilltimes(0);
						workBill.setBuildtime(new Date());
						workBill.setCourier(courier);
						workBill.setOrder(order);
						workBill.setPickstate("新单");
						workBill.setRemark(order.getRemark());
						workBill.setSmsNumber("123");
						workBill.setType("新");
						workbillDao.save(workBill);//保存工单
						//调用短信平台为快递员发送短信
						System.out.println("工单信息：请到"+order.getSendAddress()+"取件，客户电话："+order.getSendMobile());
						return ;
					}
				}
			}
		}
		//5、如果没有完成自动分单，转入人工调度
		order.setOrderType("人工分单");
	}
}
