package com.itheima.bos.service.base.impl;

import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.itheima.bos.dao.base.SubareaDao;
import com.itheima.bos.domain.base.SubArea;
import com.itheima.bos.service.base.SubareaService;

@Service
@Transactional
public class SubareaServiceImpl implements SubareaService{
	@Resource
	private SubareaDao dao;
	public void save(SubArea model) {
		String id = UUID.randomUUID().toString();
		model.setId(id);
		dao.save(model);
	}
	
	public List<SubArea> findAll() {
		return dao.findAll();
	}

	public List<Object[]> findSubareas() {
		return dao.findSubareas();
	}
}
