package com.itheima.bos.service.system;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.itheima.bos.domain.system.Menu;
import com.itheima.bos.domain.system.User;

public interface MenuService {

	public List<Menu> findAll();

	public void save(Menu model);

	public Page<Menu> pageQuery(Pageable pageable);

	public List<Menu> findByUser(User user);

}
