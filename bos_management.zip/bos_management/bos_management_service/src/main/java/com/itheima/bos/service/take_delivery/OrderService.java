package com.itheima.bos.service.take_delivery;

import javax.jws.WebService;

import com.itheima.bos.domain.take_delivery.Order;

@WebService
public interface OrderService {
	/**
	 * 保存订单，实现自动分单方法
	 */
	public void save(Order order);
}
