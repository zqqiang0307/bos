package com.itheima.bos.jobs;

import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.itheima.bos.dao.take_delivery.WorkbillDao;
import com.itheima.bos.domain.base.Area;
import com.itheima.bos.domain.take_delivery.WorkBill;
import com.itheima.bos.utils.MailUtils;

/**
 * 自定义任务，定时发送邮件
 */
public class MailJob {
	
	

	
	@Autowired
	private WorkbillDao workbillDao;
	/**
	 * 发送邮件,邮件内容为所有的工单信息
	 */
	public void sendMail(){
		System.out.println("发送邮件了：" + new Date());
		//查询所有工单信息
		List<WorkBill> list = workbillDao.findAll();
		String subject = "工单信息统计";//邮件主题
		String content = "工单编号   工单类型   取件状态   快递员 <br>";//邮件内容
		for (WorkBill workBill : list) {
			content += workBill.getId() + "  " + workBill.getType() + "  " + workBill.getPickstate() + "  " + workBill.getCourier().getName() + "<br>";
		}
		String to = "test@itcast.cn";//收件人
		//调用工具类发送邮件
		MailUtils.sendMail(subject, content, to);
	}
}
