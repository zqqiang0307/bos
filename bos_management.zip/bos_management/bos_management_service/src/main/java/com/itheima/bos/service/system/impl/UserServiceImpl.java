package com.itheima.bos.service.system.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.itheima.bos.dao.system.UserDao;
import com.itheima.bos.domain.system.Role;
import com.itheima.bos.domain.system.User;
import com.itheima.bos.service.system.UserService;
@Service
@Transactional
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDao dao;
	/**
	 * 保存一个用户，同时需要关联角色
	 * @param user
	 * @param roleIds
	 */
	public void save(User user, Integer[] roleIds) {
		dao.save(user);//持久状态的对象
		if(roleIds != null && roleIds.length > 0){
			for (Integer roleId : roleIds) {
				Role role = new Role();
				role.setId(roleId);
				user.getRoles().add(role);
			}
		}
	}
	public List<User> findAll() {
		return dao.findAll();
	}

}
