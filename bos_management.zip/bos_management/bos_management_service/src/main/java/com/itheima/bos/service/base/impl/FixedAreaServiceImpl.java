package com.itheima.bos.service.base.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.itheima.bos.dao.base.CourierDao;
import com.itheima.bos.dao.base.FixedAreaDao;
import com.itheima.bos.dao.base.TaketimeDao;
import com.itheima.bos.domain.base.Courier;
import com.itheima.bos.domain.base.FixedArea;
import com.itheima.bos.domain.base.TakeTime;
import com.itheima.bos.service.base.FixedAreaService;
@Service
@Transactional
public class FixedAreaServiceImpl implements FixedAreaService {
	@Autowired
	private FixedAreaDao dao;
	
	@Autowired
	private CourierDao courierDao;
	
	@Autowired
	private TaketimeDao taketimeDao;
	
	public void save(FixedArea model) {
		dao.save(model);
	}
	
	public Page<FixedArea> pageQuery(Pageable pageable) {
		return dao.findAll(pageable);
	}
	
	/**
	 * 定区关联快递员
	 */
	public void associationCourierToFixedArea(String id, Integer courierId, Integer takeTimeId) {
		//根据id查询定区对象，对象状态为持久状态
		FixedArea fixedArea = dao.findOne(id);
		//根据id查询快递员对象，对象状态为持久状态
		Courier courier = courierDao.findOne(courierId);
		fixedArea.getCouriers().add(courier);//定区关联快递员
		//courier.getFixedAreas().add(fixedArea);//快递员关联定区
		TakeTime takeTime = taketimeDao.findOne(takeTimeId);
		courier.setTakeTime(takeTime);//快递员关联时间
	}
}
