package com.itheima.bos.service.base.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.itheima.bos.dao.base.CourierDao;
import com.itheima.bos.domain.base.Courier;
import com.itheima.bos.domain.base.Standard;
import com.itheima.bos.service.base.CourierService;
@Service
@Transactional
public class CouierServiceImpl implements CourierService {
	@Autowired
	private CourierDao dao;
	public void save(Courier model) {
		dao.save(model);
	}
	public Page<Courier> pageQuery(Pageable pageable) {
		return dao.findAll(pageable);
	}
	
	/**
	 * 快递员批量删除（逻辑删除）
	 */
	//通过注解方式标识调用当前方法需要具有的权限
	@RequiresPermissions("courier:delete")
	public void deleteBatch(String ids) {
		if(StringUtils.isNotBlank(ids)){
			String[] courierIds = ids.split(",");
			for (String id : courierIds) {
				int courierId = Integer.parseInt(id);
				dao.deleteCourier(courierId);
			}
		}
	}
	
	/**
	 * 带有条件的分页查询
	 */
	public Page<Courier> pageQuery(Specification<Courier> spec, Pageable pageable) {
		return dao.findAll(spec, pageable);
	}
	
	/**
	 * 查询所有未删除的快递员
	 */
	public List<Courier> findCouriersNotDelete() {
		return dao.findByDeltagIsNull();
	}
}
