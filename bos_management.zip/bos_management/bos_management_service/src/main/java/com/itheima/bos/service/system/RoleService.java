package com.itheima.bos.service.system;

import java.util.List;

import com.itheima.bos.domain.system.Role;

public interface RoleService {

	public List<Role> findAll();

	public void save(Role model, String menuIds, Integer[] permissionIds);

}
