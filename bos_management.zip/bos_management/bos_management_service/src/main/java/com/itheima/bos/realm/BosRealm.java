package com.itheima.bos.realm;

import java.util.List;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;

import com.itheima.bos.dao.system.PermissionDao;
import com.itheima.bos.dao.system.RoleDao;
import com.itheima.bos.dao.system.UserDao;
import com.itheima.bos.domain.system.Permission;
import com.itheima.bos.domain.system.Role;
import com.itheima.bos.domain.system.User;

/**
 * 自定义realm，实现认证和授权
 */
public class BosRealm extends AuthorizingRealm{
	@Autowired
	private UserDao userDao;
	@Autowired
	private RoleDao roleDao;
	@Autowired
	private PermissionDao permissionDao;
	/**
	 * 认证方法
	 */
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
		UsernamePasswordToken passwordToken = (UsernamePasswordToken)token;
		String username = passwordToken.getUsername();//获取页面输入的username
		//根据username查询数据库
		User user = userDao.findByUsername(username);
		if(user == null){
			//没有查询到数据
			return null;
		}
		//构造简单认证信息对象，封装密码，user
		AuthenticationInfo info = new SimpleAuthenticationInfo(user, user.getPassword(), this.getName());
		return info;
	}
	
	/**
	 * 授权方法
	 */
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
		SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
		// 后期需要根据当前登录用户查询数据库获取实际对应的权限
		Subject subject = SecurityUtils.getSubject();
		User user = (User) subject.getPrincipal();
		if(user.getUsername().equals("admin")){
			//当前用户是内置的超级管理员，查询所有的权限、角色，进行授权
			List<Role> roleList = roleDao.findAll();
			for (Role role : roleList) {
				info.addRole(role.getKeyword());//使用角色的关键字作为角色的标识
			}
			List<Permission> permissionList = permissionDao.findAll();
			for (Permission permission : permissionList) {
				info.addStringPermission(permission.getKeyword());//使用权限的关键字作为权限的标识
			}
		}else{
			List<Role> roleList = roleDao.findByUser(user.getId());
			for (Role role : roleList) {
				info.addRole(role.getKeyword());//使用角色的关键字作为角色的标识
			}
			List<Permission> permissionList = permissionDao.findByUser(user.getId());
			for (Permission permission : permissionList) {
				info.addStringPermission(permission.getKeyword());//使用权限的关键字作为权限的标识
			}
		}
		
		return info;
	}
}
