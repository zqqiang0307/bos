package com.itheima.bos.service.take_delivery;

import com.itheima.bos.domain.take_delivery.WayBill;

public interface WaybillService {

	void save(WayBill model);

}
