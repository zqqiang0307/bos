package com.itheima.bos.service.system;

import java.util.List;

import com.itheima.bos.domain.system.User;

public interface UserService {

	public void save(User model, Integer[] roleIds);

	public List<User> findAll();

}
