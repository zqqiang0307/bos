package com.itheima.bos.service.system.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.itheima.bos.dao.system.RoleDao;
import com.itheima.bos.domain.system.Menu;
import com.itheima.bos.domain.system.Permission;
import com.itheima.bos.domain.system.Role;
import com.itheima.bos.service.system.RoleService;
@Service
@Transactional
public class RoleServiceImpl implements RoleService{
	@Autowired
	private RoleDao dao;
	public List<Role> findAll() {
		return dao.findAll();
	}
	
	/**
	 * 保存一个角色，同时需要角色关联菜单和权限
	 */
	public void save(Role role, String menuIds, Integer[] permissionIds) {
		dao.save(role);//保存后role对象状态由瞬时变为持久的
		if(StringUtils.isNotBlank(menuIds)){
			//逗号进行分割
			String[] mIds = menuIds.split(",");
			for (String menuId : mIds) {
				Menu menu = new Menu();
				menu.setId(Integer.parseInt(menuId));//手动构造脱管状态的对象
				role.getMenus().add(menu);//持久对象关联脱管对象,才能够同步到数据库
			}
		}
		if(permissionIds != null && permissionIds.length > 0){
			for (Integer permissionId : permissionIds) {
				Permission permission = new Permission();
				permission.setId(permissionId);
				role.getPermissions().add(permission);
			}
		}
	}
}
