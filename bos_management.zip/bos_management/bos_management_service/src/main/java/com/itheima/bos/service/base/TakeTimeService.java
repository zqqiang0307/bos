package com.itheima.bos.service.base;

import java.util.List;

import com.itheima.bos.domain.base.TakeTime;

public interface TakeTimeService {

	public List<TakeTime> findAll();

}
