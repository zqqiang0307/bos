package com.itheima.bos.dao.base;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.itheima.bos.domain.base.SubArea;

public interface SubareaDao extends JpaRepository<SubArea, String> {
	//select a.c_province,count(*)  from T_SUB_AREA t inner join t_area a on t.c_area_id = a.c_id group by a.c_province
	@Query(value="select a.province,count(*) from SubArea s inner join s.area a group by a.province")
	public List<Object[]> findSubareas();

}
