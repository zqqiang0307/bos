package com.itheima.bos.dao.base;

import org.springframework.data.jpa.repository.JpaRepository;

import com.itheima.bos.domain.base.TakeTime;

public interface TaketimeDao extends JpaRepository<TakeTime, Integer> {

}
