package com.itheima.bos.dao.base;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import com.itheima.bos.domain.base.Standard;

public interface StandardDao extends JpaRepository<Standard, Integer>{
	//根据spring data JPA命名规则指定方法名称
	public Standard findByNameLike(String name);
	//public Standard findByName(String name);
	//public List<Standard> findByName(String name);
	public List<Standard> findByNameIsNull();
	@Query("from Standard s where s.name like ?")//JPQL
	public Standard findByNamexxxLike(String name);
	@Query(value="select * from T_STANDARD s where s.C_NAME  like ?",nativeQuery=true)//SQL
	public Standard findByNamexxLike(String name);
	@Query("from Standard s where s.name like ?2 and s.operator = ?1")//JPQL
	public List<Standard> findByNameAndOperatorxxx(String name,String operator);
	@Modifying
	@Query("delete from Standard s where s.name = ?")//JPQL
	public void  deleteByName(String name);
	
}