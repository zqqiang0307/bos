package com.itheima.bos.dao.take_delivery;

import org.springframework.data.jpa.repository.JpaRepository;

import com.itheima.bos.domain.take_delivery.WorkBill;

public interface WorkbillDao extends JpaRepository<WorkBill, Integer> {

}
