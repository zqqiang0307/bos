package com.itheima.bos.dao.base;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.itheima.bos.domain.base.Area;

public interface AreaDao extends JpaRepository<Area, String> {
	//public List<Area> findByProvinceLikeOrCityLikeOrDistrictLikeOrShortcodeLikeOrCitycodeLike();
	@Query("from Area a where a.province like ?1 or a.city like ?1 or a.district like ?1 or a.shortcode like ?1 or a.citycode like ?1")
	public List<Area> findByQ(String q);
	
	public Area findByProvinceAndCityAndDistrict(String province,String city,String district);
}
